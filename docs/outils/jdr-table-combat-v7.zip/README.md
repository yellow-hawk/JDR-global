# ⚔ Table de Combat JDR — L'Épée de Vérité

## Présentation

Outil web standalone de combat tactique pour jeu de rôle, conçu pour la campagne **Boîtes d'Orden** (univers L'Épée de Vérité, Terry Goodkind). Fichier HTML unique, aucune dépendance externe, utilisable offline.

**Version actuelle :** v7  
**Fichier principal :** `jdr-battle-map-v7.html`  
**Guide utilisateur :** `jdr-guide-v6.html`

---

## Contenu du ZIP

| Fichier | Description |
|---|---|
| `jdr-battle-map-v7.html` | Application complète (version courante) |
| `jdr-guide-v6.html` | Tutoriel HTML interactif (15 sections) |
| `README.md` | Ce document |
| `HISTORIQUE.md` | Historique complet des versions v1→v7 |

---

## Lancer l'outil

Ouvrir `jdr-battle-map-v7.html` dans n'importe quel navigateur moderne (Chrome, Firefox, Edge). Tout fonctionne en local, rien n'est envoyé sur internet.

---

## Architecture technique

- **Rendu :** Canvas 2D avec support HiDPI (`devicePixelRatio`)
- **Grille :** Carrée (classique) ou hexagonale (pointy-top, Red Blob Games standard)
- **Coordonnées hex :** Axiales (q, r), conversion cube-round, `hexSize = gs / √3`
- **Zoom/Pan :** Système monde-écran séparé — `worldToScreen(wx,wy)` / `screenToWorld(sx,sy)`
- **Snap cellule :** `worldToCell(wx,wy)` pour le placement discret des tokens
- **Drag :** Préserve l'offset du point de grab (pas de "saut" au centre)
- **Taille :** ~1300 lignes, ~130 fonctions, fichier unique
- **Persistance :** `localStorage` (sauvegarde rapide) + export/import JSON
- **Polices :** Cinzel (titres), Crimson Text (corps), JetBrains Mono (données)
- **Sons :** Web Audio API (oscillateurs synthétiques, pas de fichiers audio)

---

## Fonctionnalités complètes (v7)

### Navigation
- Molette = zoom centré sur le curseur
- Clic molette / clic droit / Alt+clic = pan
- Boutons +/−/⌂ en bas de carte
- Drag & drop d'images pour fond de carte

### Grille
- Carrée ou hexagonale, basculement instantané
- Hex engine : pointy-top, axial (q,r), formules Red Blob Games vérifiées par tests unitaires
- Taille de grille ajustable (15-80 px)

### Tokens (entités)
- 4 catégories : PCs (bleu), Alliés (vert), Ennemis (rouge), Neutres (orange)
- Stats complètes : PV, CA, vitesse, FOR/DEX/CON/INT/SAG/CHA avec modificateurs
- Taille : 1 (Petit/Moyen) à 4 (Gargantuesque)
- Conditions : 18 prédéfinies + personnalisées, buffs et debuffs visuellement distincts
- Auras : zones colorées persistantes centrées sur le token
- Champs v7 : `visionRange` (portée de vue), `damageFormula` (ex: "1d10+3")
- Drag & drop fluide en carrée et hexagonale

### Combat
- Initiative automatique (d20+DEX) ou manuelle
- Tracker de tours avec flags : Action, Bonus, Réaction, Mouvement
- Skip automatique des tokens à 0 PV
- Compteur de rounds

### Sorts (Grimoire)
- 9 sorts pré-configurés (Boule de feu, Bénédiction, Souffle du dragon, Éclair, Mur de force, Tempête de grêle, Ténèbres, Feu de sorcier, Confession)
- 5 formes : cercle, cône, ligne, carré, rectangle
- Workflow de lancement : sélection lanceur → choix sort → preview pulsante → position/rotation → confirmation
- Effets automatiques : dégâts, soins, conditions appliqués aux cibles
- Concentration : jet de CON automatique sur dégâts (DD = max(10, dégâts/2))
- Particules visuelles : feu, glace, foudre, sacré, ténèbres
- Portée affichée en cercle doré
- Cibles surlignées en temps réel
- Créateur/éditeur de sorts personnalisés

### Zones de terrain
- 7 types : Terrain difficile, Infranchissable, Eau, Élévation, Couvert, Antimagie, Mur opaque
- Formes : cercle, carré, polygone point-à-point
- Patterns visuels distincts (hachures, croix, vagues, points)
- Chaque type a des propriétés mécaniques : `moveCost`, `blocks`, `blocksSight`

### Brouillard de guerre
- Pinceau révéler/cacher, taille ajustable
- Tout cacher / tout révéler
- S'active automatiquement en mode Joueur

### Outils
- Mesure de distance (cases + mètres, 1 case = 1.5m)
- Lanceur de dés : d4-d100, formules (2d6+4), avantage/désavantage

### Gestion des zones (panneau gauche)
- Liste de toutes les zones (sorts séparés des terrains)
- Sélection, redimensionnement par slider, suppression individuelle
- Suppression par catégorie (sorts / terrains / tout)

### Bibliothèque & Import
- Templates de créatures réutilisables (3 pré-configurés : Garde D'Haran, Mriswith, Dragon rouge)
- Spawn en un clic au centre de la vue
- Import SRD : coller un bloc de stats → parsing automatique (EN/FR)
- Sauvegarder un token existant dans la bibliothèque

### Mode Joueur / MJ
- Mode MJ : accès complet
- Mode Joueur : PV/stats ennemis masqués, ennemis invisibles cachés, fog auto

---

## Fonctionnalités ajoutées en v7

### Undo/Redo
- `Ctrl+Z` / `Ctrl+Y` ou boutons ↶ / ↷
- Stack de 30 snapshots
- Couvre toutes les actions : déplacement, dégâts, conditions, sorts, création/suppression

### Portée de mouvement
- Bouton 🏃 dans la barre d'outils
- BFS (Breadth-First Search) depuis la position du token
- Coût par case : 1 (normal), 2 (terrain difficile), ∞ (infranchissable/occupé)
- Budget = vitesse du token
- Overlay vert des cases atteignables
- Chemin avec coût affiché au survol
- Tracking du mouvement utilisé par tour

### Ligne de vue dynamique
- Bouton 👁 dans la barre d'outils
- Raycasting depuis chaque PC/allié
- Portée de vision paramétrable par token (défaut 12 cases)
- Bloquée par Infranchissable et Mur opaque
- Révèle automatiquement le brouillard pour les cases visibles

### Effets automatiques des terrains
- Log automatique quand un token entre dans un terrain
- Mouvement bloqué par les cases infranchissables (revert automatique)
- Antimagie annule les sorts au lancement

### Jets d'attaque intégrés
- Boutons ⚔ Mêlée (portée 2) et 🏹 Distance (portée 8) sur chaque token
- Clic sur cible → d20+mod FOR vs CA
- Application automatique des dégâts (formule configurable par token)
- Coup critique : doublement des dés
- Échec critique sur 1 naturel
- Jet de concentration automatique sur la cible si applicable
- Log détaillé dans le journal

### Templates de rencontres
- Section "Rencontres" dans le panneau gauche
- Sauvegarder : snapshot tokens + terrain sous un nom
- Charger : restaure le setup complet en un clic
- Supprimer des rencontres sauvegardées

### Thèmes visuels
- 🌑 Sombre (défaut) — fond noir, accents dorés
- 📜 Parchemin — tons chauds, ambiance médiévale
- ⚡ Contraste — noir pur, couleurs vives, accessibilité
- Variables CSS pour tous les éléments

### Sons
- Web Audio API (oscillateurs synthétiques)
- Dés : clic percussif
- Sort : whoosh
- Tour : cloche
- Impact : thud
- Toggle on/off dans ⚙

### Terrain "Mur opaque"
- Bloque à la fois le mouvement ET la vue
- Utile pour les murs, portes fermées, etc.

---

## Raccourcis clavier

| Raccourci | Action |
|---|---|
| `Ctrl+Z` | Annuler |
| `Ctrl+Y` / `Ctrl+Shift+Z` | Rétablir |
| `Échap` | Annuler sort/attaque/polygone, désélectionner |
| `Entrée` | Fermer un polygone en cours |
| `Molette` | Zoom (ou rotation de sort pendant le lancement) |
| `Clic molette` | Pan (déplacer la vue) |
| `Clic droit` | Pan (alternative) |
| `Alt + Clic` | Pan (alternative) |
| `Double-clic` | Fermer un polygone en cours |

---

## Données pré-configurées

### Personnages (univers L'Épée de Vérité)

| Nom | Type | PV | CA | Vit | FOR | DEX | CON | INT | SAG | CHA | Dégâts |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Richard | PC | 52 | 18 | 6 | 16 | 14 | 14 | 12 | 13 | 16 | 1d10+3 |
| Kahlan | PC | 36 | 14 | 6 | 10 | 14 | 12 | 14 | 16 | 18 | 1d8+1 |
| Zedd | PC | 28 | 12 | 5 | 8 | 10 | 10 | 20 | 18 | 14 | 1d4 |
| Cara | Allié | 42 | 16 | 6 | 16 | 16 | 14 | 10 | 12 | 12 | 1d8+3 |
| Garde D'Haran | Ennemi | 18 | 14 | 6 | 14 | 12 | 12 | 8 | 10 | 8 | 1d6+2 |
| Mriswith | Ennemi | 48 | 17 | 8 | 18 | 16 | 16 | 6 | 12 | 6 | 2d6+4 |

### Sorts

| Sort | Forme | Rayon | Portée | Origine | Concentration | Effet |
|---|---|---|---|---|---|---|
| Boule de feu | Cercle | 4 | 24 | Point | Non | 28 dégâts feu + En feu |
| Bénédiction | Cercle | 3 | 6 | Point | Oui | Béni |
| Souffle du dragon | Cône | 5 | 0 | Soi | Non | 21 dégâts feu |
| Éclair | Ligne | 20 | 0 | Soi | Non | 24 dégâts foudre |
| Mur de force | Rectangle | 6 | 18 | Point | Oui | — |
| Tempête de grêle | Cercle | 4 | 20 | Point | Non | 18 dégâts froid + Ralenti |
| Ténèbres | Cercle | 3 | 10 | Point | Oui | Aveuglé |
| Feu de sorcier | Cône | 6 | 0 | Soi | Non | 32 dégâts feu magique |
| Confession | Cercle | 1 | 1 | Soi | Non | Confessé |

---

## Moteur hexagonal — détails techniques

### Formules (pointy-top, axial q,r)

```
hexSize = gs / √3

Cell(q,r) → World pixel :
  x = hexSize × (√3 × q + √3/2 × r)
  y = hexSize × (3/2 × r)

World pixel → Cell(q,r) :
  q_frac = (√3/3 × x − 1/3 × y) / hexSize
  r_frac = (2/3 × y) / hexSize
  → cube_round(q_frac, r_frac)

Distance hex :
  dist(q1,r1,q2,r2) = (|q1−q2| + |q1+r1−q2−r2| + |r1−r2|) / 2

Voisins (6 directions) :
  [+1,0] [+1,−1] [0,−1] [−1,0] [−1,+1] [0,+1]

Coins du hex (pointy-top) :
  angle_i = 60° × i − 30°  (i = 0..5)
  corner_i = center + size × (cos(angle_i), sin(angle_i))
```

### Vérification

Les formules ont été validées par tests unitaires (Node.js) couvrant :
- Round-trip cellule → pixel → cellule : 7 cellules testées, 100% correct
- Clics à l'intérieur d'un hex : 15 positions testées, 100% correct
- Stabilité aux frontières entre cellules : vérifié
- Position du curseur vs snapping : pas de décalage vertical

---

## Contexte du projet

Cet outil fait partie de l'écosystème de la campagne JDR **Boîtes d'Orden**, qui comprend également :
- Bible de lore (272 pages, Campfire/Amsel)
- Architecture narrative (6 arcs, 17 chapitres, 58 scènes)
- Système de magie "Atelier de Traçage" (générateur HTML, lexique à deux niveaux)
- Grimoire "Le Livre de l'Encre" (PDF 20 pages)
- Bibliothèque D&D 5e (bestiaire, sorts, objets)
- Diagramme de relations interactif
- Visualiseur de graphe 3D
- Glossaire HTML (190 entrées)

---

## Licence

Outil personnel, usage privé. Développé par Joseph Saigne Le Boulc'h avec assistance Claude (Anthropic).
