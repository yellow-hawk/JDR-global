# Historique des versions

## v1 — Base
- Grille carrée canvas, CRUD de tokens (PCs/NPCs)
- Catégories PCs/Alliés/Ennemis/Neutres
- PV, CA, initiative, conditions
- Zones de sort : cercle, cône, ligne, carré

## v2 — Système de jeu
- Opacités réglables (carte, tokens)
- Sorts avec presets et application automatique des effets
- Zones mobiles, forme rectangle ajoutée
- Stats complètes (FOR/DEX/CON/INT/SAG/CHA)
- Initiative d20+DEX
- Sauvegarde JSON + localStorage

## v3 — Outils de MJ
- Brouillard de guerre (pinceau révéler/cacher)
- Journal de combat horodaté
- Mesure de distance (cases + mètres)
- Lanceur de dés (d4-d100 + formules)
- Auras persistantes sur tokens
- Mode Joueur vs MJ (masquage stats ennemis)
- Bibliothèque de créatures + Import SRD
- Gestion de tours (action/bonus/réaction/mouvement)
- Concentration avec jets de CON auto
- Particules visuelles (feu/glace/foudre/sacré/ténèbres)

## v4 — Refonte sorts
- Workflow de lancement revu : sélection lanceur → sort → preview → position/rotation → confirmation
- Cercle de portée doré
- Surlignage des cibles en temps réel
- Barre de lancement (cast bar) avec compteur de cibles
- Mode joueur active le fog automatiquement
- Templates de sorts avec champs forme/portée/origine/concentration/particules

## v5 — Hexagonal (première tentative)
- Grille hexagonale ajoutée (flat-top, buggée)
- Initiative manuelle ou automatique
- Opacités séparées pour zones sort vs terrain
- 6 types de terrain avec patterns visuels
- **Bugs connus :** moteur hex incohérent, zoom cassé, drag décalé

## v6 — Corrections & zones
- Moteur de coordonnées réécrit : séparation "pixels monde" / "coordonnées cellule"
- Zoom centré sur le curseur corrigé
- Navigation : clic molette = pan, clic droit = pan
- Drag des tokens par delta pixel (plus fluide)
- Panneau de gestion des zones (liste, sélection, suppression, redimensionnement)
- Terrain polygonal (tracé point-à-point, double-clic pour fermer)
- Tutoriel HTML complet (jdr-guide-v6.html)
- **Bugs restants :** moteur hex encore imprécis ("trop haut"), flat-top vs pointy-top incohérent

## v7 — Version majeure (actuelle)

### Refonte moteur hex
- Réécriture complète selon le standard Red Blob Games
- Pointy-top, coordonnées axiales (q, r), cube rounding
- `hexSize = gs / √3`, formules vérifiées par tests unitaires
- Drag tokens/zones : offset du point de grab préservé

### Nouvelles fonctionnalités
- **Undo/Redo** — Ctrl+Z/Ctrl+Y, stack de 30 snapshots
- **Portée de mouvement** — BFS avec coûts de terrain, overlay vert, chemin + coût au survol
- **Ligne de vue** — raycasting depuis PCs/alliés, bloqué par murs/infranchissable, révèle le brouillard
- **Effets automatiques des terrains** — log d'entrée, blocage mouvement, antimagie bloque les sorts
- **Jets d'attaque** — ⚔ Mêlée / 🏹 Distance, d20+mod vs CA, dégâts auto, crits, concentration
- **Templates de rencontres** — sauvegarder/charger des setups complets
- **3 thèmes** — Sombre, Parchemin, Contraste
- **Sons** — Web Audio (dés, sorts, cloche, impact), toggle on/off
- **Terrain "Mur opaque"** — bloque mouvement et vue
- Champs token ajoutés : `visionRange`, `damageFormula`
